import Header from '@/components/layout/Header';
import StudyRoomClient from '@/components/study-room/StudyRoomClient'; // This will be the client component handling room logic
import { Button } from '@/components/ui/button';
import { ChevronLeft } from 'lucide-react';
import Link from 'next/link';

export default function StudyRoomPage({ params }: { params: { id: string } }) {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-grow container mx-auto p-2 md:p-4">
        <div className="mb-4">
          <Button variant="outline" asChild>
            <Link href="/">
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Link>
          </Button>
        </div>
        <StudyRoomClient roomId={params.id} />
      </main>
      <footer className="text-center p-4 text-muted-foreground text-sm border-t">
        StudySphere Room ID: {params.id}
      </footer>
    </div>
  );
}
