import AiPracticeGenerator from "@/components/ai-practice/AiPracticeGenerator";
import FeatureCard from "@/components/dashboard/FeatureCard";
import UserNav from "@/components/layout/UserNav"; // Changed import
import NotesPanel from "@/components/notes/NotesPanel";
import PomodoroTimer from "@/components/pomodoro/PomodoroTimer";
import StudyRoomsSection from "@/components/study-room/StudyRoomsSection";
import TaskList from "@/components/tasks/TaskList";
import { Brain, Edit3Icon, MessageSquareHeart, ShieldCheck, TimerIcon, Users2 } from "lucide-react"; 
import Image from "next/image";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 text-foreground">
      <header className="py-4 px-6 border-b shadow-sm sticky top-0 bg-background/80 backdrop-blur-md z-50">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            {/* Replace Brain with an Image component for your logo if you have one */}
            {/* <Brain className="h-7 w-7 text-primary" /> */}
            <Image src="/logo.svg" alt="StudySphere Logo" width={32} height={32} className="text-primary" data-ai-hint="logo brain"/>
            <h1 className="text-2xl font-headline font-bold">StudySphere</h1>
          </div>
          <UserNav /> {/* Replaced placeholder with UserNav */}
        </div>
      </header>

      <main className="container mx-auto p-4 md:p-6 lg:p-8">
        <section className="text-center mb-10">
          <h2 className="text-4xl font-headline font-bold mb-3 text-primary">
            Welcome to StudySphere
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Your all-in-one platform for focused study sessions, task management, and AI-powered learning assistance.
          </p>
        </section>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 xl:gap-8">
          <FeatureCard title="Pomodoro Timer" icon={TimerIcon} className="lg:col-span-1">
            <p className="text-sm text-muted-foreground mb-3">
              Boost productivity with timed focus sessions.
            </p>
            <PomodoroTimer />
          </FeatureCard>

          <FeatureCard title="Task List" icon={ShieldCheck} className="lg:col-span-1">
             <p className="text-sm text-muted-foreground mb-3">
              Organize your study goals and track progress.
            </p>
            <TaskList />
          </FeatureCard>

          <FeatureCard title="Quick Notes" icon={Edit3Icon} className="lg:col-span-1">
             <p className="text-sm text-muted-foreground mb-3">
              Jot down ideas and key points on the fly.
            </p>
            <NotesPanel />
          </FeatureCard>

          <FeatureCard title="AI Practice Questions" icon={MessageSquareHeart} className="md:col-span-2 lg:col-span-3">
             <p className="text-sm text-muted-foreground mb-3">
              Generate practice questions from your study materials using AI.
            </p>
            <AiPracticeGenerator />
          </FeatureCard>
          
          <FeatureCard title="Collaborative Study Rooms" icon={Users2} className="md:col-span-2 lg:col-span-3">
             <p className="text-sm text-muted-foreground mb-3">
              Connect with peers, share knowledge, and study together in virtual rooms.
            </p>
            <StudyRoomsSection />
          </FeatureCard>

        </div>
      </main>

      <footer className="text-center p-6 text-muted-foreground text-xs border-t mt-8">
        &copy; {new Date().getFullYear()} StudySphere. Focus. Learn. Achieve.
      </footer>
    </div>
  );
}
