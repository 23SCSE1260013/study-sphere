"use client";

import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { MailIcon, UserIcon, CalendarIcon, Edit3Icon, Loader2 } from 'lucide-react';
import { signOutAction } from '@/app/_actions/authActions';
import { useToast } from '@/hooks/use-toast';
import Link from 'next/link';
import Image from 'next/image';

export default function ProfilePage() {
  const { currentUser, userProfile, loading } = useAuth();
  const router = useRouter();
  const { toast } = useToast();

  useEffect(() => {
    if (!loading && !currentUser) {
      router.push('/login');
    }
  }, [currentUser, loading, router]);

  const handleSignOut = async () => {
    const result = await signOutAction();
    if (result.success) {
      toast({ title: "Signed Out", description: "You have been successfully signed out." });
      router.push('/login');
      router.refresh();
    } else {
      toast({ title: "Sign Out Failed", description: result.error || "Could not sign out.", variant: "destructive" });
    }
  };

  if (loading || !currentUser || !userProfile) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background text-foreground">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  const getInitials = (name?: string | null) => {
    if (!name) return userProfile.email?.charAt(0).toUpperCase() || 'U';
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };
  
  const formatDate = (timestamp: any) => {
    if (!timestamp || !timestamp.toDate) return 'N/A';
    return timestamp.toDate().toLocaleDateString();
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 text-foreground p-4 md:p-8">
      <header className="py-4 px-6 mb-8">
        <div className="container mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 group">
            <Image src="/logo.svg" alt="StudySphere Logo" width={32} height={32} className="text-primary" data-ai-hint="logo brain"/>
            <h1 className="text-2xl font-headline font-bold text-foreground transition-colors group-hover:text-primary/90">StudySphere</h1>
          </Link>
          <Button onClick={handleSignOut} variant="outline">Logout</Button>
        </div>
      </header>
      
      <main className="container mx-auto max-w-2xl">
        <Card className="shadow-xl">
          <CardHeader className="text-center">
            <Avatar className="w-24 h-24 mx-auto mb-4 border-4 border-primary shadow-md">
              <AvatarImage src={userProfile.photoURL || `https://placehold.co/100x100.png?text=${getInitials(userProfile.displayName)}`} alt={userProfile.displayName || 'User'} data-ai-hint="profile avatar" />
              <AvatarFallback>{getInitials(userProfile.displayName)}</AvatarFallback>
            </Avatar>
            <CardTitle className="text-3xl font-headline text-primary">{userProfile.displayName || 'User Profile'}</CardTitle>
            <CardDescription>Manage your StudySphere account details.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-md">
                <UserIcon className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-xs text-muted-foreground">Display Name</p>
                  <p className="font-medium">{userProfile.displayName}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-md">
                <MailIcon className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-xs text-muted-foreground">Email</p>
                  <p className="font-medium">{userProfile.email}</p>
                </div>
              </div>
               <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-md">
                <CalendarIcon className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-xs text-muted-foreground">Joined On</p>
                  <p className="font-medium">{formatDate(userProfile.createdAt)}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-md">
                <Edit3Icon className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-xs text-muted-foreground">Bio</p>
                  <p className="font-medium italic">{userProfile.bio || 'No bio set.'}</p>
                </div>
              </div>
            </div>
            <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground" disabled>
              <Edit3Icon className="mr-2 h-4 w-4" /> Edit Profile (Coming Soon)
            </Button>
          </CardContent>
        </Card>
      </main>
      <footer className="text-center p-6 text-muted-foreground text-xs mt-12">
        &copy; {new Date().getFullYear()} StudySphere. Focus. Learn. Achieve.
      </footer>
    </div>
  );
}
