
"use client";

import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { VideoIcon, VideoOffIcon, RadioIcon, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import Header from '@/components/layout/Header'; // Assuming a generic header exists or can be adapted
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function BroadcastPage() {
  const { currentUser, loading: authLoading } = useAuth();
  const router = useRouter();
  const { toast } = useToast();

  const [streamTitle, setStreamTitle] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [isLoading, setIsLoading] = useState(false); // For "Go Live" button

  const videoRef = useRef<HTMLVideoElement>(null);
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);

  useEffect(() => {
    if (!authLoading && !currentUser) {
      router.push('/login?redirect=/broadcast');
    }
  }, [currentUser, authLoading, router]);

  useEffect(() => {
    const getCameraPermission = async () => {
      if (!currentUser) return; // Only request if logged in
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        setHasCameraPermission(true);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (error) {
        console.error('Error accessing camera/mic:', error);
        setHasCameraPermission(false);
        toast({
          variant: 'destructive',
          title: 'Media Access Denied',
          description: 'Please enable camera and microphone permissions in your browser settings.',
        });
      }
    };

    if (currentUser) { // Check if currentUser is loaded
        getCameraPermission();
    }
    
    // Cleanup
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [currentUser, toast]);


  const handleToggleCamera = () => {
    const newCameraState = !isCameraOn;
    setIsCameraOn(newCameraState);
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getVideoTracks().forEach(track => track.enabled = newCameraState);
    }
    toast({ title: `Camera ${newCameraState ? 'enabled' : 'disabled'}` });
  };

  const handleGoLive = async () => {
    if (!streamTitle.trim()) {
      toast({ title: "Stream title required", description: "Please enter a title for your stream.", variant: "destructive" });
      return;
    }
    if (hasCameraPermission === false) {
      toast({ title: "Camera Permission Needed", description: "Cannot start stream without camera access.", variant: "destructive" });
      return;
    }

    setIsLoading(true);
    // Simulate API call to start stream
    await new Promise(resolve => setTimeout(resolve, 1500)); 
    
    setIsStreaming(true);
    setIsLoading(false);
    toast({ title: "You are Live!", description: `Stream "${streamTitle}" has started.` });
    console.log(`User ${currentUser?.displayName || currentUser?.email} started stream: "${streamTitle}"`);
    // In a real app, you'd save stream info to Firestore here
    // and initiate the actual streaming connection.
  };

  const handleStopStream = () => {
    setIsStreaming(false);
    toast({ title: "Stream Ended", description: "Your public stream has ended." });
    console.log(`Stream "${streamTitle}" ended.`);
    // In a real app, update Firestore and terminate streaming connection.
  };

  if (authLoading || !currentUser) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background text-foreground">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-background to-muted/30">
      <Header /> 
      <main className="flex-grow container mx-auto p-4 md:p-8 flex items-center justify-center">
        <Card className="w-full max-w-2xl shadow-xl">
          <CardHeader>
            <CardTitle className="font-headline text-2xl text-primary">
              {isStreaming ? `Live: ${streamTitle}` : "Start a Public Stream"}
            </CardTitle>
            <CardDescription>
              {isStreaming ? "You are currently live to the public." : "Share your study session or thoughts with the community."}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="aspect-video bg-muted rounded-md flex items-center justify-center relative overflow-hidden">
              <video ref={videoRef} className="w-full h-full object-cover" autoPlay muted playsInline />
              {(!isCameraOn || hasCameraPermission === false) && (
                <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center text-white">
                  <VideoOffIcon className="w-16 h-16" />
                  {hasCameraPermission === false && <p className="mt-2 text-sm">Camera access denied.</p>}
                  {!isCameraOn && hasCameraPermission !== false && <p className="mt-2 text-sm">Camera is off.</p>}
                </div>
              )}
              {hasCameraPermission === null && (
                 <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center text-white">
                    <Loader2 className="h-8 w-8 animate-spin mr-2"/> Requesting camera access...
                 </div>
               )}
            </div>

            {hasCameraPermission === false && (
                <Alert variant="destructive">
                    <AlertTitle>Camera/Microphone Access Denied</AlertTitle>
                    <AlertDescription>
                        To start a stream, StudySphere needs access to your camera and microphone. 
                        Please enable these permissions in your browser settings and refresh the page.
                    </AlertDescription>
                </Alert>
            )}

            {!isStreaming && (
              <div className="space-y-2">
                <Label htmlFor="streamTitle">Stream Title</Label>
                <Input 
                  id="streamTitle" 
                  value={streamTitle} 
                  onChange={(e) => setStreamTitle(e.target.value)} 
                  placeholder="e.g., Quantum Physics AMA, My Coding Journey" 
                  disabled={isLoading}
                />
              </div>
            )}
          </CardContent>
          <CardFooter className="flex flex-col sm:flex-row justify-between gap-3">
            <Button variant={isCameraOn ? "outline" : "secondary"} onClick={handleToggleCamera} disabled={isLoading || isStreaming || hasCameraPermission === false}>
              {isCameraOn ? <VideoOffIcon className="mr-2"/> : <VideoIcon className="mr-2"/>}
              {isCameraOn ? "Turn Camera Off" : "Turn Camera On"}
            </Button>
            {isStreaming ? (
              <Button onClick={handleStopStream} variant="destructive" className="w-full sm:w-auto">
                <RadioIcon className="mr-2" /> Stop Streaming
              </Button>
            ) : (
              <Button onClick={handleGoLive} disabled={isLoading || hasCameraPermission === false} className="w-full sm:w-auto bg-green-600 hover:bg-green-700 text-white">
                {isLoading ? <Loader2 className="mr-2 animate-spin"/> : <RadioIcon className="mr-2" />}
                Go Live
              </Button>
            )}
          </CardFooter>
        </Card>
      </main>
      <footer className="text-center p-6 text-muted-foreground text-xs border-t">
        &copy; {new Date().getFullYear()} StudySphere. Share your focus.
      </footer>
    </div>
  );
}

// Minimal Header component if not already globally available or for specific styling
// For this example, we assume `Header` is imported from `src/components/layout/Header.tsx`
// and it's a generic header. If it needs specific props or context, adjust accordingly.
// If you don't have a shared Header, you can create a simple one here or import the one from the main page.
// import Link from 'next/link';
// import Image from 'next/image';
// const MinimalHeader = () => (
//   <header className="py-4 px-6 border-b shadow-sm sticky top-0 bg-background/80 backdrop-blur-md z-50">
//     <div className="container mx-auto flex items-center justify-between">
//       <Link href="/" className="flex items-center gap-2">
//         <Image src="/logo.svg" alt="StudySphere Logo" width={32} height={32} className="text-primary" data-ai-hint="logo brain"/>
//         <h1 className="text-2xl font-headline font-bold">StudySphere</h1>
//       </Link>
//     </div>
//   </header>
// );
