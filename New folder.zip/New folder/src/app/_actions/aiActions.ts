"use server";

import { generatePracticeQuestions, type GeneratePracticeQuestionsInput, type GeneratePracticeQuestionsOutput } from '@/ai/flows/generate-practice-questions';

export async function getPracticeQuestionsAction(input: GeneratePracticeQuestionsInput): Promise<GeneratePracticeQuestionsOutput | { error: string }> {
  try {
    const result = await generatePracticeQuestions(input);
    return result;
  } catch (error) {
    console.error("Error generating practice questions:", error);
    // It's good practice to not expose raw error messages to the client.
    // Provide a generic error message or a more specific one if you can identify the error type.
    if (error instanceof Error) {
        return { error: `Failed to generate questions: ${error.message}` };
    }
    return { error: "An unexpected error occurred while generating questions." };
  }
}
