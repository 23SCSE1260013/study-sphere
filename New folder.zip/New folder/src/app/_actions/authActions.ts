
"use server";

import { 
  auth, 
  db, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  firebaseSignOut,
  doc,
  setDoc,
  getDoc, // Added getDoc
  serverTimestamp
} from '@/lib/firebase';
import type { UserProfile } from '@/lib/types';
// Removed unused AI related imports from this file
// import { generatePracticeQuestions, type GeneratePracticeQuestionsInput, type GeneratePracticeQuestionsOutput } from '@/ai/flows/generate-practice-questions';

// export async function getPracticeQuestionsAction(input: GeneratePracticeQuestionsInput): Promise<GeneratePracticeQuestionsOutput | { error: string }> {
//   try {
//     const result = await generatePracticeQuestions(input);
//     return result;
//   } catch (error) {
//     console.error("Error generating practice questions:", error);
//     if (error instanceof Error) {
//         return { error: `Failed to generate questions: ${error.message}` };
//     }
//     return { error: "An unexpected error occurred while generating questions." };
//   }
// }

export async function signUpWithEmailAction(formData: FormData): Promise<{ success: boolean; error?: string; userId?: string }> {
  const email = formData.get('email') as string;
  const password = formData.get('password') as string;
  const displayName = formData.get('displayName') as string | null;

  if (!email || !password) {
    return { success: false, error: "Email and password are required." };
  }

  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    const userProfileData: UserProfile = {
      uid: user.uid,
      email: user.email,
      displayName: displayName || user.email?.split('@')[0] || 'New User',
      photoURL: user.photoURL,
      createdAt: serverTimestamp() as any, 
    };
    await setDoc(doc(db, "users", user.uid), userProfileData);

    return { success: true, userId: user.uid };
  } catch (error: any) {
    console.error("Signup error:", error);
    return { success: false, error: error.message || "Failed to sign up." };
  }
}

export async function signInWithEmailAction(formData: FormData): Promise<{ success: boolean; error?: string; userId?: string }> {
  const email = formData.get('email') as string;
  const password = formData.get('password') as string;

  if (!email || !password) {
    return { success: false, error: "Email and password are required." };
  }

  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return { success: true, userId: userCredential.user.uid };
  } catch (error: any) {
    console.error("Signin error:", error);
    return { success: false, error: error.message || "Failed to sign in." };
  }
}

export async function signOutAction(): Promise<{ success: boolean; error?: string }> {
  try {
    await firebaseSignOut(auth);
    return { success: true };
  } catch (error: any) {
    console.error("Signout error:", error);
    return { success: false, error: error.message || "Failed to sign out." };
  }
}

export async function ensureUserProfileWithGoogleAction(userData: {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}): Promise<{ success: boolean; error?: string; userId?: string; isNewUser?: boolean }> {
  if (!userData.uid) {
    return { success: false, error: "User ID is missing." };
  }

  try {
    const userDocRef = doc(db, "users", userData.uid);
    const userDocSnap = await getDoc(userDocRef);

    let isNewUser = false;
    if (!userDocSnap.exists()) {
      isNewUser = true;
      const userProfileData: UserProfile = {
        uid: userData.uid,
        email: userData.email,
        displayName: userData.displayName || userData.email?.split('@')[0] || 'New User',
        photoURL: userData.photoURL,
        createdAt: serverTimestamp() as any,
      };
      await setDoc(userDocRef, userProfileData);
    }
    // If user already exists, we don't need to do anything here,
    // but you could add logic to update last login time, etc.

    return { success: true, userId: userData.uid, isNewUser };
  } catch (error: any) {
    console.error("Google Sign-in - Profile Ensure Error:", error);
    return { success: false, error: error.message || "Failed to ensure user profile." };
  }
}
