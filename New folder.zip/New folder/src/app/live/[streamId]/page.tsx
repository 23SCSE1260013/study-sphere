
"use client";

import { useEffect, useState } from 'react';
import Image from 'next/image';
import Header from '@/components/layout/Header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { SendIcon, UserIcon, UsersIcon, MessageSquareIcon, EyeIcon, Loader2 } from 'lucide-react';
import Link from 'next/link';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';


interface MockStreamDetails {
  id: string;
  title: string;
  streamerName: string;
  streamerAvatar: string;
  description: string;
  category: string;
  viewers: number;
  isLive: boolean;
  videoPlaceholderUrl: string;
}

// Mock function to get stream details
const fetchStreamDetails = async (streamId: string): Promise<MockStreamDetails | null> => {
  console.log("Fetching mock stream details for:", streamId);
  await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate network delay
  if (streamId.startsWith("stream-")) { // Basic check if it's one of our mock IDs
    return {
      id: streamId,
      title: `Live Study Session: ${streamId.replace("stream-", "").replace(/-/g, " ")}`,
      streamerName: "DynamicStreamer",
      streamerAvatar: "https://placehold.co/80x80.png?text=DS",
      description: "Join this live session to learn about various interesting topics and interact with the community. This is a placeholder description for the stream.",
      category: "General Studies",
      viewers: Math.floor(Math.random() * 300) + 50,
      isLive: true,
      videoPlaceholderUrl: "https://placehold.co/1280x720.png",
    };
  }
  return null;
};


export default function ViewStreamPage({ params }: { params: { streamId: string } }) {
  const [streamDetails, setStreamDetails] = useState<MockStreamDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [chatMessages, setChatMessages] = useState<{ user: string; message: string; avatar: string }[]>([]);
  const [chatInput, setChatInput] = useState('');

  useEffect(() => {
    const loadStream = async () => {
      setLoading(true);
      const details = await fetchStreamDetails(params.streamId);
      setStreamDetails(details);
      setLoading(false);
      // Mock initial chat messages
      if (details) {
        setChatMessages([
          { user: "StudyBot", message: `Welcome to ${details.streamerName}'s stream!`, avatar: "https://placehold.co/32x32.png?text=SB" },
          { user: "Viewer123", message: "Excited for this session!", avatar: "https://placehold.co/32x32.png?text=V1" },
        ]);
      }
    };
    loadStream();
  }, [params.streamId]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (chatInput.trim() && streamDetails) {
      setChatMessages(prev => [...prev, { user: 'You', message: chatInput, avatar: 'https://placehold.co/32x32.png?text=U' }]);
      setChatInput('');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-grow container mx-auto p-4 md:p-8 flex items-center justify-center">
          <Loader2 className="h-16 w-16 animate-spin text-primary" />
        </main>
      </div>
    );
  }

  if (!streamDetails) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-grow container mx-auto p-4 md:p-8 text-center">
          <h1 className="text-2xl font-bold text-destructive mt-10">Stream Not Found</h1>
          <p className="text-muted-foreground">The stream you are looking for does not exist or has ended.</p>
          <Button asChild className="mt-6">
            <Link href="/live">Back to Live Streams</Link>
          </Button>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-grow container mx-auto p-2 md:p-4 flex flex-col lg:flex-row gap-4 max-h-[calc(100vh-80px)] overflow-hidden">
        {/* Video Player Section */}
        <div className="flex-grow lg:w-3/4 flex flex-col space-y-4">
          <Card className="shadow-lg overflow-hidden flex-shrink-0">
            <div className="aspect-video bg-black relative">
              <Image 
                src={streamDetails.videoPlaceholderUrl} 
                alt="Live stream placeholder" 
                layout="fill" 
                objectFit="contain" 
                data-ai-hint="live stream screen"
              />
              {streamDetails.isLive && (
                <div className="absolute top-3 left-3 bg-red-600 text-white px-3 py-1 rounded-md text-sm font-semibold animate-pulse">LIVE</div>
              )}
               <div className="absolute bottom-3 right-3 bg-black/70 text-white px-2 py-1 rounded-md text-sm flex items-center">
                <EyeIcon className="h-4 w-4 mr-1.5" /> {streamDetails.viewers} viewers
              </div>
            </div>
          </Card>
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle className="font-headline text-2xl text-primary">{streamDetails.title}</CardTitle>
              <div className="flex items-center space-x-3 text-sm text-muted-foreground mt-1">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={streamDetails.streamerAvatar} alt={streamDetails.streamerName} data-ai-hint="profile avatar" />
                  <AvatarFallback>{streamDetails.streamerName.charAt(0)}</AvatarFallback>
                </Avatar>
                <span>{streamDetails.streamerName}</span>
                <span className="px-2 py-0.5 bg-accent text-accent-foreground rounded-full text-xs">{streamDetails.category}</span>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-foreground/80">{streamDetails.description}</p>
            </CardContent>
          </Card>
        </div>

        {/* Chat Section */}
        <Card className="lg:w-1/4 shadow-md flex flex-col max-h-full min-h-0">
          <CardHeader className="pb-2 border-b">
            <CardTitle className="font-headline text-lg flex items-center">
              <MessageSquareIcon className="mr-2 h-5 w-5 text-primary" /> Live Chat
            </CardTitle>
          </CardHeader>
          <CardContent className="flex-grow overflow-hidden flex flex-col p-3 space-y-2 min-h-0">
            <ScrollArea className="flex-grow pr-2 mb-2 min-h-[100px]">
              <div className="space-y-3">
                {chatMessages.map((msg, i) => (
                  <div key={i} className={`flex items-start gap-2 text-sm ${msg.user === 'You' ? 'justify-end' : ''}`}>
                    {msg.user !== 'You' && (
                       <Avatar className="h-6 w-6">
                        <AvatarImage src={msg.avatar} alt={msg.user} data-ai-hint="profile avatar small" />
                        <AvatarFallback>{msg.user.charAt(0)}</AvatarFallback>
                      </Avatar>
                    )}
                    <div className={`p-2 rounded-lg max-w-[85%] ${msg.user === 'You' ? 'bg-primary text-primary-foreground ml-auto' : 'bg-muted'}`}>
                      <p className={`font-semibold text-xs mb-0.5 ${msg.user === 'You' ? '' : 'text-foreground/90'}`}>{msg.user}</p>
                      <p>{msg.message}</p>
                    </div>
                     {msg.user === 'You' && (
                       <Avatar className="h-6 w-6">
                        <AvatarImage src={msg.avatar} alt={msg.user} data-ai-hint="profile avatar small" />
                        <AvatarFallback>{msg.user.charAt(0)}</AvatarFallback>
                      </Avatar>
                    )}
                  </div>
                ))}
                {chatMessages.length === 0 && <p className="text-xs text-center text-muted-foreground py-4">Chat is quiet. Say hello!</p>}
              </div>
            </ScrollArea>
            <form onSubmit={handleSendMessage} className="flex gap-2 items-center pt-2 border-t mt-auto">
              <Input value={chatInput} onChange={(e) => setChatInput(e.target.value)} placeholder="Send a message..." className="flex-grow" />
              <Button type="submit" size="icon" className="bg-primary hover:bg-primary/90"><SendIcon /></Button>
            </form>
          </CardContent>
        </Card>
      </main>
      {/* Footer can be minimal or removed for stream view if space is tight */}
       {/* <footer className="text-center p-2 text-muted-foreground text-xs border-t">
        &copy; {new Date().getFullYear()} StudySphere.
      </footer> */}
    </div>
  );
}
