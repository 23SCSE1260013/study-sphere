
"use client";

import Link from 'next/link';
import Image from 'next/image';
import Header from '@/components/layout/Header'; // Assuming a generic header
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { EyeIcon, UserIcon } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Skeleton } from '@/components/ui/skeleton';

// Mock data for public streams
interface MockStream {
  id: string;
  title: string;
  streamerName: string;
  streamerAvatar: string;
  thumbnailUrl: string;
  viewers: number;
  category: string;
}

const mockLiveStreams: MockStream[] = [
  { id: 'stream-calculus-live', title: '🔴 Live: Solving Hard Calculus Problems', streamerName: 'MathWhiz', streamerAvatar: 'https://placehold.co/40x40.png?text=MW', thumbnailUrl: 'https://placehold.co/600x400.png', viewers: 125, category: 'Mathematics' , dataAiHint: "lecture math" },
  { id: 'stream-coding-deep-work', title: 'Deep Work: Building a Next.js App', streamerName: 'CodeNinja', streamerAvatar: 'https://placehold.co/40x40.png?text=CN', thumbnailUrl: 'https://placehold.co/600x400.png', viewers: 230, category: 'Programming', dataAiHint: "code screen" },
  { id: 'stream-history-review', title: 'WWII History Lecture Q&A', streamerName: 'HistoryFan', streamerAvatar: 'https://placehold.co/40x40.png?text=HF', thumbnailUrl: 'https://placehold.co/600x400.png', viewers: 78, category: 'History', dataAiHint: "old map scroll" },
  { id: 'stream-art-session', title: 'Chill Art & Study Session 🎨', streamerName: 'ArtisticLearner', streamerAvatar: 'https://placehold.co/40x40.png?text=AL', thumbnailUrl: 'https://placehold.co/600x400.png', viewers: 150, category: 'Creative', dataAiHint: "painting canvas" },
];

export default function LiveStreamsPage() {
  const [loadingStreams, setLoadingStreams] = useState(true);

  useEffect(() => {
    // Simulate fetching streams
    const timer = setTimeout(() => {
      setLoadingStreams(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-background to-muted/30">
      <Header />
      <main className="flex-grow container mx-auto p-4 md:p-8">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-headline font-bold text-primary mb-2">
            Live Study Streams
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Watch fellow learners study, discuss topics, and share their knowledge in real-time.
          </p>
        </div>

        {loadingStreams ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <Card key={i} className="overflow-hidden shadow-lg">
                <Skeleton className="w-full h-48" />
                <CardHeader>
                  <Skeleton className="h-6 w-3/4 mb-1" />
                  <Skeleton className="h-4 w-1/2" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-4 w-1/4" />
                </CardContent>
                <CardFooter>
                  <Skeleton className="h-10 w-full" />
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : mockLiveStreams.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mockLiveStreams.map((stream) => (
              <Card key={stream.id} className="overflow-hidden shadow-lg flex flex-col group hover:shadow-primary/30 transition-shadow duration-300">
                <Link href={`/live/${stream.id}`} className="block">
                  <div className="relative aspect-video">
                    <Image 
                        src={stream.thumbnailUrl} 
                        alt={stream.title} 
                        layout="fill" 
                        objectFit="cover" 
                        className="group-hover:scale-105 transition-transform duration-300"
                        data-ai-hint={stream.dataAiHint || "study person"}
                    />
                    <div className="absolute top-2 left-2 bg-red-600 text-white px-2 py-0.5 rounded-md text-xs font-semibold">LIVE</div>
                    <div className="absolute bottom-2 right-2 bg-black/70 text-white px-2 py-0.5 rounded-md text-xs flex items-center">
                      <EyeIcon className="h-3 w-3 mr-1" /> {stream.viewers}
                    </div>
                  </div>
                </Link>
                <CardHeader className="pb-2">
                  <Link href={`/live/${stream.id}`} className="block">
                    <CardTitle className="font-headline text-lg hover:text-primary transition-colors">{stream.title}</CardTitle>
                  </Link>
                  <CardDescription className="text-xs">
                    <span className="font-medium text-primary">{stream.category}</span>
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-0 pb-3 flex-grow">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Image src={stream.streamerAvatar} alt={stream.streamerName} width={24} height={24} className="rounded-full mr-2" data-ai-hint="profile avatar" />
                    <span>{stream.streamerName}</span>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button asChild className="w-full bg-primary hover:bg-primary/90">
                    <Link href={`/live/${stream.id}`}>Watch Stream</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <VideoOffIcon className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-xl font-semibold mb-2">No Live Streams Currently</h2>
            <p className="text-muted-foreground">Check back later or be the first to start a stream!</p>
            <Button asChild className="mt-4">
              <Link href="/broadcast">Go Live</Link>
            </Button>
          </div>
        )}
      </main>
      <footer className="text-center p-6 text-muted-foreground text-xs border-t mt-8">
        &copy; {new Date().getFullYear()} StudySphere. Watch, learn, and grow together.
      </footer>
    </div>
  );
}
