"use client";
import AuthForm from '@/components/auth/AuthForm';
import { signInWithEmailAction } from '@/app/_actions/authActions';
import { Brain } from 'lucide-react';
import Link from 'next/link';

export default function LoginPage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-background to-muted/30 p-4">
      <div className="absolute top-6 left-6">
        <Link href="/" className="flex items-center gap-2 text-foreground hover:text-primary transition-colors">
          <Brain className="h-7 w-7 text-primary" />
          <span className="text-xl font-bold font-headline">StudySphere</span>
        </Link>
      </div>
      <AuthForm mode="login" action={signInWithEmailAction} />
       <footer className="text-center p-6 text-muted-foreground text-xs mt-8 absolute bottom-0">
        &copy; {new Date().getFullYear()} StudySphere. Focus. Learn. Achieve.
      </footer>
    </div>
  );
}
