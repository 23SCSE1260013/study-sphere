"use client";

import { useState, useEffect, useCallback, useRef } from 'react';
import type { PomodoroSettings } from '@/lib/types';

export enum PomodoroSessionType {
  Work = 'Work',
  Break = 'Break',
}

const DEFAULT_SETTINGS: PomodoroSettings = {
  workDuration: 25,
  breakDuration: 5,
};

export function usePomodoro(initialSettings?: Partial<PomodoroSettings>) {
  const [settings, setSettings] = useState<PomodoroSettings>({ ...DEFAULT_SETTINGS, ...initialSettings });
  const [timeLeft, setTimeLeft] = useState(settings.workDuration * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [currentSessionType, setCurrentSessionType] = useState<PomodoroSessionType>(PomodoroSessionType.Work);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const switchSession = useCallback(() => {
    if (currentSessionType === PomodoroSessionType.Work) {
      setCurrentSessionType(PomodoroSessionType.Break);
      setTimeLeft(settings.breakDuration * 60);
    } else {
      setCurrentSessionType(PomodoroSessionType.Work);
      setTimeLeft(settings.workDuration * 60);
    }
  }, [currentSessionType, settings]);

  useEffect(() => {
    if (isRunning) {
      if (timeLeft <= 0) {
        switchSession();
        // Potentially add a sound notification here
      }
      timerRef.current = setTimeout(() => {
        setTimeLeft((prevTime) => prevTime - 1);
      }, 1000);
    } else {
      if (timerRef.current) clearTimeout(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [isRunning, timeLeft, switchSession]);

  useEffect(() => {
    // Reset timer when settings change and not running
    if (!isRunning) {
        setTimeLeft(currentSessionType === PomodoroSessionType.Work ? settings.workDuration * 60 : settings.breakDuration * 60);
    }
  }, [settings, currentSessionType, isRunning]);


  const startPause = () => {
    setIsRunning(!isRunning);
  };

  const reset = useCallback(() => {
    setIsRunning(false);
    setCurrentSessionType(PomodoroSessionType.Work);
    setTimeLeft(settings.workDuration * 60);
  }, [settings.workDuration]);

  const updateSettings = (newSettings: Partial<PomodoroSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const skipSession = () => {
    setIsRunning(false); // Stop timer before switching
    switchSession();
  };

  return {
    timeLeft,
    isRunning,
    currentSessionType,
    startPause,
    reset,
    settings,
    updateSettings,
    skipSession,
  };
}
