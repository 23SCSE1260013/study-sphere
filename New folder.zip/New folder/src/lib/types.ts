import type { Timestamp } from "firebase/firestore";

export type Task = {
  id: string;
  text: string;
  completed: boolean;
};

export type PomodoroSettings = {
  workDuration: number; // in minutes
  breakDuration: number; // in minutes
};

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName?: string | null;
  photoURL?: string | null;
  bio?: string;
  createdAt: Timestamp;
  // Add other customizable fields here
}
