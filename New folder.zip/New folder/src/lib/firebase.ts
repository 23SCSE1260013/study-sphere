// Import the functions you need from the SDKs you need
import { initializeApp, getApp, getApps, type FirebaseApp } from "firebase/app";
import { 
  getAuth, 
  type Auth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut, // Renamed to avoid conflict with potential local signOut
  onAuthStateChanged,
  GoogleAuthProvider, // Added for potential future use
  signInWithPopup // Added for potential future use
} from "firebase/auth";
import { 
  getFirestore, 
  type Firestore,
  doc,
  setDoc,
  getDoc,
  serverTimestamp 
} from "firebase/firestore";
import { getStorage, type FirebaseStorage } from "firebase/storage";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB3m_h39hK4PxzO_uSx9tA4uaWwHJ2A9hs", // Make sure this is the correct key you want to use
  authDomain: "focusrealms.firebaseapp.com",
  projectId: "focusrealms",
  storageBucket: "focusrealms.appspot.com", // Ensure this is correct, often ends with .appspot.com
  messagingSenderId: "660673366381",
  appId: "1:660673366381:web:b16994fb336da83de4f264",
  measurementId: "G-N3SGGLEL32"
};

// Initialize Firebase
let app: FirebaseApp;
if (!getApps().length) {
  app = initializeApp(firebaseConfig);
} else {
  app = getApp();
}

const auth: Auth = getAuth(app);
const db: Firestore = getFirestore(app);
const storage: FirebaseStorage = getStorage(app);

export { 
  app, 
  auth, 
  db, 
  storage, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  firebaseSignOut, 
  onAuthStateChanged,
  GoogleAuthProvider,
  signInWithPopup,
  doc,
  setDoc,
  getDoc,
  serverTimestamp
};