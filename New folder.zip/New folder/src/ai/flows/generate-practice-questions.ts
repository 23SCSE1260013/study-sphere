'use server';

/**
 * @fileOverview An AI agent that generates practice questions from study materials.
 *
 * - generatePracticeQuestions - A function that generates practice questions based on the provided study material URL.
 * - GeneratePracticeQuestionsInput - The input type for the generatePracticeQuestions function.
 * - GeneratePracticeQuestionsOutput - The return type for the generatePracticeQuestions function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GeneratePracticeQuestionsInputSchema = z.object({
  studyMaterialUrl: z
    .string()
    .url()
    .describe('URL of the study material to generate questions from.'),
});
export type GeneratePracticeQuestionsInput = z.infer<
  typeof GeneratePracticeQuestionsInputSchema
>;

const GeneratePracticeQuestionsOutputSchema = z.object({
  questions: z
    .array(z.string())
    .describe('An array of practice questions generated from the study material.'),
});
export type GeneratePracticeQuestionsOutput = z.infer<
  typeof GeneratePracticeQuestionsOutputSchema
>;

export async function generatePracticeQuestions(
  input: GeneratePracticeQuestionsInput
): Promise<GeneratePracticeQuestionsOutput> {
  return generatePracticeQuestionsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generatePracticeQuestionsPrompt',
  input: {schema: GeneratePracticeQuestionsInputSchema},
  output: {schema: GeneratePracticeQuestionsOutputSchema},
  prompt: `You are an AI study assistant. Generate practice questions from the study material provided in the following URL: {{{studyMaterialUrl}}}. Return the questions as an array of strings.`,
});

const generatePracticeQuestionsFlow = ai.defineFlow(
  {
    name: 'generatePracticeQuestionsFlow',
    inputSchema: GeneratePracticeQuestionsInputSchema,
    outputSchema: GeneratePracticeQuestionsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
