"use client";

import type { Task } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Trash2Icon } from 'lucide-react';

interface TaskItemProps {
  task: Task;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

export default function TaskItem({ task, onToggle, onDelete }: TaskItemProps) {
  return (
    <div className="flex items-center space-x-3 p-2 border-b last:border-b-0 hover:bg-muted/50 transition-colors duration-150 rounded-md">
      <Checkbox
        id={`task-${task.id}`}
        checked={task.completed}
        onCheckedChange={() => onToggle(task.id)}
        aria-labelledby={`task-label-${task.id}`}
      />
      <label
        htmlFor={`task-${task.id}`}
        id={`task-label-${task.id}`}
        className={`flex-grow text-sm cursor-pointer ${task.completed ? 'line-through text-muted-foreground' : 'text-foreground'}`}
      >
        {task.text}
      </label>
      <Button variant="ghost" size="icon" onClick={() => onDelete(task.id)} aria-label={`Delete task: ${task.text}`}>
        <Trash2Icon className="h-4 w-4 text-destructive/80 hover:text-destructive" />
      </Button>
    </div>
  );
}
