"use client";

import { useState, useEffect } from 'react';
import type { Task } from '@/lib/types';
import TaskItem from './TaskItem';
import AddTaskForm from './AddTaskForm';
import { ScrollArea } from '@/components/ui/scroll-area';

export default function TaskList() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
    // Load tasks from localStorage on initial client-side render
    const storedTasks = localStorage.getItem('studySphereTasks');
    if (storedTasks) {
      setTasks(JSON.parse(storedTasks));
    }
  }, []);

  useEffect(() => {
    // Save tasks to localStorage whenever they change
    if(isClient) {
      localStorage.setItem('studySphereTasks', JSON.stringify(tasks));
    }
  }, [tasks, isClient]);

  const addTask = (text: string) => {
    const newTask: Task = {
      id: crypto.randomUUID(),
      text,
      completed: false,
    };
    setTasks(prevTasks => [newTask, ...prevTasks]);
  };

  const toggleTask = (id: string) => {
    setTasks(prevTasks =>
      prevTasks.map(task =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const deleteTask = (id: string) => {
    setTasks(prevTasks => prevTasks.filter(task => task.id !== id));
  };
  
  if (!isClient) {
     return (
        <div className="space-y-3">
          <div className="flex space-x-2 items-center">
            <div className="h-10 bg-muted rounded-md flex-grow animate-pulse"></div>
            <div className="h-10 w-10 bg-muted rounded-md animate-pulse"></div>
          </div>
          <div className="space-y-2">
            {[1,2,3].map(i => (
              <div key={i} className="flex items-center space-x-3 p-2 border-b h-10 bg-muted/50 rounded-md animate-pulse"></div>
            ))}
          </div>
        </div>
     );
  }

  return (
    <div className="space-y-4 h-full flex flex-col">
      <AddTaskForm onAddTask={addTask} />
      {tasks.length > 0 ? (
        <ScrollArea className="flex-grow pr-3 min-h-[100px] max-h-[250px]"> {/* Adjusted max-h */}
          <div className="space-y-2">
            {tasks.map(task => (
              <TaskItem
                key={task.id}
                task={task}
                onToggle={toggleTask}
                onDelete={deleteTask}
              />
            ))}
          </div>
        </ScrollArea>
      ) : (
        <p className="text-center text-muted-foreground py-4">No tasks yet. Add some!</p>
      )}
    </div>
  );
}
