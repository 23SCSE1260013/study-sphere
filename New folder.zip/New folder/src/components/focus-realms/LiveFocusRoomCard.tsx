"use client";

import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle2Icon } from 'lucide-react';
import { Progress } from '@/components/ui/progress'; // For timer representation
import { useEffect, useState } from 'react';

export default function LiveFocusRoomCard() {
  const [timeLeft, setTimeLeft] = useState(25 * 60); // 25 minutes in seconds
  const [progress, setProgress] = useState(100);

  useEffect(() => {
    // This is a mock timer effect. For a real timer, you'd use setInterval.
    const timer = setTimeout(() => {
      if (timeLeft > 0) {
        // setTimeLeft(timeLeft - 1);
        // setProgress(((timeLeft - 1) / (25 * 60)) * 100);
      }
    }, 1000);
    return () => clearTimeout(timer);
  }, [timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Card className="bg-card text-card-foreground shadow-xl flex flex-col h-full">
      <CardHeader>
        <CardTitle className="font-headline text-xl">Live Focus Room</CardTitle>
      </CardHeader>
      <CardContent className="flex-grow flex flex-col justify-between space-y-4">
        <div className="relative aspect-[16/9] w-full rounded-md overflow-hidden group">
          <Image 
            src="https://placehold.co/600x338.png" 
            alt="Forest study scene" 
            layout="fill" 
            objectFit="cover" 
            className="group-hover:scale-105 transition-transform duration-300"
            data-ai-hint="study desk window" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent"></div>
          <div className="absolute top-2 left-2 bg-black/50 text-white text-xs px-2 py-1 rounded-full">Forest</div>
        </div>
        
        <div className="space-y-3">
          <div className="text-center">
            <div className="text-5xl font-mono font-bold text-primary">{formatTime(timeLeft)}</div>
            {/* <Progress value={progress} className="h-1.5 mt-1 [&>div]:bg-primary" /> */}
          </div>

          <ul className="space-y-1.5 text-sm text-muted-foreground">
            <li className="flex items-center">
              <CheckCircle2Icon className="h-4 w-4 mr-2 text-primary/80" />
              <span>Read Chapter 5</span>
            </li>
            <li className="flex items-center">
              <CheckCircle2Icon className="h-4 w-4 mr-2 text-primary/80" />
              <span>Take notes</span>
            </li>
            <li className="flex items-center">
              <CheckCircle2Icon className="h-4 w-4 mr-2 text-primary/80" />
              <span>Review key points</span>
            </li>
          </ul>
        </div>
        
        <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-3">Join</Button>
      </CardContent>
    </Card>
  );
}
