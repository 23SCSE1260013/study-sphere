"use client";

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

export default function AiFocusBuddyCard() {
  return (
    <Card className="bg-card text-card-foreground shadow-xl">
      <CardHeader>
        <CardTitle className="font-headline text-lg">AI Focus Buddy</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-end space-x-2">
          <Avatar className="h-9 w-9 self-start">
            <AvatarImage src="https://placehold.co/40x40.png?text=AI" alt="AI Buddy" data-ai-hint="profile avatar cartoon" />
            <AvatarFallback>AI</AvatarFallback>
          </Avatar>
          <div className="bg-primary/80 text-primary-foreground p-3 rounded-lg rounded-bl-none max-w-[80%]">
            <p className="text-sm">Let's plan your day! What tasks do you want to focus on?</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <div className="flex-grow h-10 bg-muted/50 rounded-md px-3 flex items-center text-muted-foreground text-sm">
            Type your tasks here...
          </div>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">Chat</Button>
        </div>
      </CardContent>
    </Card>
  );
}
