"use client";

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { MoreHorizontalIcon } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

const mockGoals = [
  {
    user: { name: 'David', avatarText: 'D', avatarImage: "https://placehold.co/40x40.png" },
    title: 'Monthly Goals',
    status: 'In Progress',
    tasks: [
      { name: 'Done', progress: 60, status: 'In Progress' },
      { name: 'In Progress', progress: 30, status: 'Stuck' },
    ],
  },
  {
    user: { name: 'Emma', avatarText: 'E', avatarImage: "https://placehold.co/40x40.png" },
    title: 'Write 500 words',
    status: 'In Progress',
    tasks: [
      { name: 'In Progress', progress: 80, status: 'Stuck' },
      { name: 'Done', progress: 20, status: 'In Progress' },
    ],
  },
  {
    user: { name: 'Alex', avatarText: 'A', avatarImage: "https://placehold.co/40x40.png" },
    title: 'Daily Tasks',
    status: 'Earned',
    tasks: [
      { name: 'Done', progress: 40, status: 'In Progress' },
      { name: 'In Progress', progress: 70, status: 'Stuck' },
    ],
  },
];

export default function GoalBoardsCard() {
  return (
    <Card className="bg-card text-card-foreground shadow-xl flex flex-col h-full">
      <CardHeader>
        <CardTitle className="font-headline text-xl">Build-in-Public Goal Boards</CardTitle>
      </CardHeader>
      <CardContent className="flex-grow space-y-3 overflow-hidden">
        <ScrollArea className="h-[350px] pr-3"> {/* Approximate height to match image */}
          <div className="space-y-4">
            {mockGoals.map((goal, index) => (
              <div key={index} className="p-3 bg-muted/30 rounded-lg space-y-2.5 shadow-sm">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-7 w-7">
                      <AvatarImage src={`${goal.user.avatarImage}?text=${goal.user.avatarText}`} alt={goal.user.name} data-ai-hint="profile avatar" />
                      <AvatarFallback>{goal.user.avatarText}</AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-medium">{goal.user.name}</span>
                  </div>
                  <MoreHorizontalIcon className="h-4 w-4 text-muted-foreground cursor-pointer" />
                </div>
                <h4 className="text-sm font-semibold text-foreground/90">{goal.title} <span className="text-xs text-primary font-normal ml-1">({goal.status})</span></h4>
                <div className="space-y-1.5">
                  {goal.tasks.map((task, taskIdx) => (
                    <div key={taskIdx} className="text-xs">
                      <div className="flex justify-between text-muted-foreground mb-0.5">
                        <span>{task.name}</span>
                        <span>{task.status}</span>
                      </div>
                      <Progress value={task.progress} className="h-1 [&>div]:bg-primary/70" />
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
