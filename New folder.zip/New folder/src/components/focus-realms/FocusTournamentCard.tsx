"use client";

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const mockTournamentData = [
  { name: 'Olivia', xp: 120, avatarText: 'O', avatarImage: "https://placehold.co/32x32.png" },
  { name: 'James', xp: 95, avatarText: 'J', avatarImage: "https://placehold.co/32x32.png" },
  { name: 'Sophia', xp: 80, avatarText: 'S', avatarImage: "https://placehold.co/32x32.png" },
];

export default function FocusTournamentCard() {
  return (
    <Card className="bg-card text-card-foreground shadow-xl">
      <CardHeader>
        <CardTitle className="font-headline text-lg">Focus Tournament</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2.5">
        {mockTournamentData.map((player, index) => (
          <div key={index} className="flex items-center justify-between p-2 bg-muted/30 rounded-md hover:bg-muted/50 transition-colors">
            <div className="flex items-center gap-2.5">
              <Avatar className="h-7 w-7">
                <AvatarImage src={`${player.avatarImage}?text=${player.avatarText}`} alt={player.name} data-ai-hint="profile avatar small" />
                <AvatarFallback>{player.avatarText}</AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium">{player.name}</span>
            </div>
            <span className="text-sm font-semibold text-primary">{player.xp} XP</span>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
