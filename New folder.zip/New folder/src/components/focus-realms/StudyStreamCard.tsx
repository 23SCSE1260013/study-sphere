"use client";

import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function StudyStreamCard() {
  return (
    <Card className="bg-card text-card-foreground shadow-xl">
      <CardHeader>
        <CardTitle className="font-headline text-lg">StudyStream 2.0 <span className="text-xs font-normal text-muted-foreground">(Live Channels)</span></CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="relative aspect-video w-full rounded-md overflow-hidden group">
          <Image 
            src="https://placehold.co/400x225.png" 
            alt="Study stream" 
            layout="fill" 
            objectFit="cover"
            className="group-hover:scale-105 transition-transform duration-300"
            data-ai-hint="person studying online"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          <span className="absolute bottom-2 left-2 bg-black/70 text-white text-xs px-2 py-0.5 rounded">37:20</span>
        </div>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold text-foreground/90">Now Studying:</p>
            <p className="text-xs text-muted-foreground">Linear Algebra</p>
          </div>
          <Button variant="outline" size="sm" className="border-primary/50 text-primary hover:bg-primary/10 hover:text-primary">Watch</Button>
        </div>
      </CardContent>
    </Card>
  );
}
