"use client";

import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function StudyWorldMapCard() {
  return (
    <Card className="bg-card text-card-foreground shadow-xl">
      <CardHeader>
        <CardTitle className="font-headline text-lg">Study World Map</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative aspect-[2/1] w-full rounded-md overflow-hidden bg-muted/40 p-2">
           <Image 
            src="https://placehold.co/400x200.png" 
            alt="World map with study locations" 
            layout="fill" 
            objectFit="contain" // or "cover" depending on desired map appearance
            data-ai-hint="world map dots"
          />
        </div>
      </CardContent>
    </Card>
  );
}
