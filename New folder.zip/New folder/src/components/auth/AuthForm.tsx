
"use client";

import { useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Loader2, LogInIcon, UserPlusIcon, ChromeIcon } from 'lucide-react'; // Added ChromeIcon as a generic "Google" icon
import Link from 'next/link';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { ensureUserProfileWithGoogleAction } from '@/app/_actions/authActions';

interface AuthFormProps {
  mode: 'login' | 'signup';
  action: (formData: FormData) => Promise<{ success: boolean; error?: string; userId?: string }>;
}

export default function AuthForm({ mode, action }: AuthFormProps) {
  const router = useRouter();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsLoading(true);
    setError(null);

    const formData = new FormData(event.currentTarget);
    const result = await action(formData);

    setIsLoading(false);

    if (result.success) {
      toast({
        title: mode === 'login' ? "Login Successful" : "Signup Successful",
        description: mode === 'login' ? "Welcome back!" : "Your account has been created.",
      });
      router.push(mode === 'signup' ? '/profile' : '/'); 
      router.refresh(); 
    } else {
      setError(result.error || 'An unexpected error occurred.');
      toast({
        title: mode === 'login' ? "Login Failed" : "Signup Failed",
        description: result.error || 'Please try again.',
        variant: "destructive",
      });
    }
  };

  const handleGoogleSignIn = async () => {
    setIsGoogleLoading(true);
    setError(null);
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const user = result.user;

      const profileResult = await ensureUserProfileWithGoogleAction({
        uid: user.uid,
        email: user.email,
        displayName: user.displayName,
        photoURL: user.photoURL,
      });

      if (profileResult.success) {
        toast({
          title: "Google Sign-In Successful",
          description: profileResult.isNewUser ? "Welcome! Your profile has been created." : "Welcome back!",
        });
        router.push(profileResult.isNewUser ? '/profile' : '/');
        router.refresh();
      } else {
        setError(profileResult.error || 'Failed to set up your profile with Google.');
        toast({
          title: "Profile Setup Failed",
          description: profileResult.error || 'Could not finalize Google sign-in.',
          variant: "destructive",
        });
      }
    } catch (error: any) {
      console.error("Google Sign-In Error:", error);
      let errorMessage = 'An unexpected error occurred during Google sign-in.';
      if (error.code === 'auth/popup-closed-by-user') {
        errorMessage = 'Google Sign-In popup was closed. Please try again.';
      } else if (error.code === 'auth/account-exists-with-different-credential') {
        errorMessage = 'An account already exists with this email address using a different sign-in method.';
      }
      setError(errorMessage);
      toast({
        title: "Google Sign-In Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsGoogleLoading(false);
    }
  };


  const title = mode === 'login' ? 'Welcome Back!' : 'Create Your Account';
  const buttonText = mode === 'login' ? 'Login' : 'Sign Up';
  const linkText = mode === 'login' ? "Don't have an account? Sign Up" : 'Already have an account? Login';
  const linkHref = mode === 'login' ? '/signup' : '/login';

  return (
    <div className="w-full max-w-md p-8 space-y-6 bg-card text-card-foreground rounded-xl shadow-2xl">
      <div className="text-center">
        {mode === 'login' ? <LogInIcon className="mx-auto h-12 w-12 text-primary" /> : <UserPlusIcon className="mx-auto h-12 w-12 text-primary" />}
        <h1 className="mt-4 text-3xl font-bold font-headline">{title}</h1>
        <p className="mt-2 text-muted-foreground">
          {mode === 'login' ? 'Access your StudySphere dashboard.' : 'Join StudySphere to boost your productivity.'}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {mode === 'signup' && (
          <div className="space-y-1.5">
            <Label htmlFor="displayName">Display Name (Optional)</Label>
            <Input id="displayName" name="displayName" type="text" placeholder="Your Name" disabled={isLoading || isGoogleLoading} />
          </div>
        )}
        <div className="space-y-1.5">
          <Label htmlFor="email">Email Address</Label>
          <Input id="email" name="email" type="email" autoComplete="email" required placeholder="you@example.com" disabled={isLoading || isGoogleLoading} />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="password">Password</Label>
          <Input id="password" name="password" type="password" autoComplete={mode === 'login' ? "current-password" : "new-password"} required placeholder="••••••••" disabled={isLoading || isGoogleLoading} minLength={6} />
        </div>

        {error && <p className="text-sm text-destructive text-center">{error}</p>}

        <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-3" disabled={isLoading || isGoogleLoading}>
          {isLoading ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : (mode === 'login' ? <LogInIcon className="mr-2 h-5 w-5" /> : <UserPlusIcon className="mr-2 h-5 w-5" />)}
          {buttonText}
        </Button>
      </form>

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-card px-2 text-muted-foreground">
            Or continue with
          </span>
        </div>
      </div>

      <Button variant="outline" className="w-full py-3" onClick={handleGoogleSignIn} disabled={isLoading || isGoogleLoading}>
        {isGoogleLoading ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <ChromeIcon className="mr-2 h-5 w-5" />} 
        Sign in with Google
      </Button>

      <p className="text-center text-sm text-muted-foreground">
        <Link href={linkHref} className="font-medium text-primary hover:underline">
          {linkText}
        </Link>
      </p>
    </div>
  );
}
