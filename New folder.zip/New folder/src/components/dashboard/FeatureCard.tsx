import type { LucideIcon } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface FeatureCardProps {
  title: string;
  icon: LucideIcon;
  children: React.ReactNode;
  className?: string;
}

export default function FeatureCard({ title, icon: Icon, children, className }: FeatureCardProps) {
  return (
    <Card className={`shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col ${className}`}>
      <CardHeader className="flex flex-row items-center space-x-3 pb-3">
        <Icon className="h-6 w-6 text-primary" />
        <CardTitle className="font-headline text-xl text-foreground">{title}</CardTitle>
      </CardHeader>
      <CardContent className="flex-grow">
        {children}
      </CardContent>
    </Card>
  );
}
