"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { PlusCircleIcon } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface CreateRoomDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function CreateRoomDialog({ open, onOpenChange }: CreateRoomDialogProps) {
  const router = useRouter();
  const { toast } = useToast();
  const [roomName, setRoomName] = useState('');
  const [roomDescription, setRoomDescription] = useState('');

  const handleCreateRoom = () => {
    if (!roomName.trim()) {
      toast({
        title: "Validation Error",
        description: "Room name cannot be empty.",
        variant: "destructive",
      });
      return;
    }
    // For now, generate a mock room ID and navigate.
    // In a real app, this would involve a backend call.
    const mockRoomId = roomName.toLowerCase().replace(/\s+/g, '-') + '-' + Date.now().toString().slice(-5);
    toast({
      title: "Room Created (Mock)",
      description: `Navigating to room: ${roomName}`,
    });
    router.push(`/study-room/${mockRoomId}`);
    onOpenChange(false); // Close dialog
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="font-headline flex items-center">
            <PlusCircleIcon className="mr-2 h-5 w-5 text-primary" /> Create New Study Room
          </DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="space-y-1">
            <Label htmlFor="roomName">Room Name</Label>
            <Input id="roomName" value={roomName} onChange={(e) => setRoomName(e.target.value)} placeholder="e.g., Quantum Physics Study Group" />
          </div>
          <div className="space-y-1">
            <Label htmlFor="roomDescription">Description (Optional)</Label>
            <Textarea id="roomDescription" value={roomDescription} onChange={(e) => setRoomDescription(e.target.value)} placeholder="A brief description of the study room's purpose." />
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button type="button" variant="outline">Cancel</Button>
          </DialogClose>
          <Button onClick={handleCreateRoom} className="bg-primary hover:bg-primary/90">Create Room</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
