
"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { PlusCircleIcon, LogInIcon, UsersIcon } from 'lucide-react';
import CreateRoomDialog from './CreateRoomDialog';
import Image from 'next/image';
import { useToast } from "@/hooks/use-toast";

// Mock data for public rooms
const mockPublicRooms = [
  { id: 'calculus-crew-123', name: 'Calculus Crew', members: 5, topic: 'Mathematics' },
  { id: 'history-buffs-456', name: 'History Buffs', members: 8, topic: 'History' },
  { id: 'code-camp-789', name: 'Code Camp', members: 12, topic: 'Programming' },
];


export default function StudyRoomsSection() {
  const [isCreateRoomDialogOpen, setIsCreateRoomDialogOpen] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  const handleJoinWithCode = () => {
    const roomCode = prompt("Enter the room code to join:");
    if (roomCode && roomCode.trim()) {
      const trimmedCode = roomCode.trim();
      toast({
        title: "Joining Room",
        description: `Attempting to join room with code: ${trimmedCode}`,
      });
      router.push(`/study-room/${trimmedCode}`);
    } else if (roomCode !== null) { // User clicked OK but entered nothing
      toast({
        title: "Invalid Code",
        description: "Please enter a valid room code.",
        variant: "destructive",
      });
    }
    // If roomCode is null, user clicked Cancel, so do nothing.
  };

  const handleJoinPublicRoom = (roomId: string, roomName: string) => {
    console.log(`Attempting to join public room: ${roomName} (${roomId})`);
    toast({
      title: "Joining Room",
      description: `Navigating to room: ${roomName}...`,
    });
    router.push(`/study-room/${roomId}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 bg-card-foreground/5 rounded-lg">
        <div>
          <h3 className="font-headline text-lg text-primary">Join or Create a Study Room</h3>
          <p className="text-sm text-muted-foreground">Collaborate with peers in real-time virtual study sessions.</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setIsCreateRoomDialogOpen(true)} className="bg-primary hover:bg-primary/90">
            <PlusCircleIcon className="mr-2 h-4 w-4" /> Create Room
          </Button>
          <Button variant="outline" onClick={handleJoinWithCode}>
            <LogInIcon className="mr-2 h-4 w-4" /> Join with Code
          </Button>
        </div>
      </div>
      
      <CreateRoomDialog open={isCreateRoomDialogOpen} onOpenChange={setIsCreateRoomDialogOpen} />

      <div>
        <h4 className="font-headline text-md mb-3 text-foreground">Public Rooms (Example)</h4>
        {mockPublicRooms.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {mockPublicRooms.map(room => (
              <div 
                key={room.id} 
                className="p-4 border rounded-lg bg-background hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => handleJoinPublicRoom(room.id, room.name)}
                onKeyDown={(e) => e.key === 'Enter' && handleJoinPublicRoom(room.id, room.name)}
                role="button"
                tabIndex={0}
              >
                <h5 className="font-semibold text-primary">{room.name}</h5>
                <p className="text-xs text-muted-foreground mb-1">{room.topic}</p>
                <div className="flex items-center text-xs text-muted-foreground">
                  <UsersIcon className="h-3 w-3 mr-1" /> {room.members} active
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-center text-muted-foreground py-4">No public rooms available currently.</p>
        )}
      </div>
       <div className="mt-6 p-4 border rounded-lg bg-background text-center">
            <Image src="https://placehold.co/600x200.png" alt="Collaborative study session" width={600} height={200} className="rounded-md mx-auto mb-2" data-ai-hint="collaboration study" />
            <p className="text-sm text-muted-foreground">Illustrative image: users collaborating in a virtual room.</p>
        </div>
    </div>
  );
}

