
"use client";

import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { MicIcon, MicOffIcon, VideoIcon, VideoOffIcon, ScreenShareIcon, ScreenShareOffIcon, RadioIcon, LogOutIcon, MessageSquareIcon, SendIcon, UsersIcon, ClockIcon, Edit3Icon } from 'lucide-react';
import PomodoroTimer from '@/components/pomodoro/PomodoroTimer';
import NotesPanel from '@/components/notes/NotesPanel';
import Image from 'next/image';
import { useToast } from "@/hooks/use-toast";
import { useRouter } from 'next/navigation';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";


interface StudyRoomClientProps {
  roomId: string;
}

// Mock participant data
const mockParticipants = [
  { id: 'user1', name: 'Alice', avatar: 'https://placehold.co/40x40.png?text=A', micOn: true, videoOn: true },
  { id: 'user2', name: 'Bob', avatar: 'https://placehold.co/40x40.png?text=B', micOn: false, videoOn: true },
  { id: 'user3', name: 'Charlie', avatar: 'https://placehold.co/40x40.png?text=C', micOn: true, videoOn: false },
  { id: 'user4', name: 'You', avatar: 'https://placehold.co/40x40.png?text=Y', micOn: true, videoOn: true },
];

export default function StudyRoomClient({ roomId }: StudyRoomClientProps) {
  const [isMicOn, setIsMicOn] = useState(true);
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [chatMessages, setChatMessages] = useState<{ user: string; message: string; time: string }[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [activeTab, setActiveTab] = useState<'chat' | 'participants'>('chat');
  const [showNotes, setShowNotes] = useState(false);
  const [showPomodoro, setShowPomodoro] = useState(false);
  const { toast } = useToast();
  const router = useRouter();
  
  const [isClient, setIsClient] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);


  useEffect(() => { 
    setIsClient(true); 
    const getCameraPermission = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        setHasCameraPermission(true);

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (error) {
        console.error('Error accessing camera:', error);
        setHasCameraPermission(false);
        toast({
          variant: 'destructive',
          title: 'Camera Access Denied',
          description: 'Please enable camera permissions in your browser settings to use this app.',
        });
      }
    };

    getCameraPermission();

    // Cleanup function to stop camera tracks when component unmounts or camera is turned off
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [toast]);


  const handleToggleMic = () => {
    const newMicState = !isMicOn;
    setIsMicOn(newMicState);
    toast({ title: `Microphone ${newMicState ? 'enabled' : 'disabled'}` });
    console.log(`Microphone toggled ${newMicState ? 'ON' : 'OFF'}`);
    // Add actual mic control logic here if using WebRTC
  };

  const handleToggleCamera = () => {
    const newCameraState = !isCameraOn;
    setIsCameraOn(newCameraState);
    toast({ title: `Camera ${newCameraState ? 'enabled' : 'disabled'}` });
    console.log(`Camera toggled ${newCameraState ? 'ON' : 'OFF'}`);
    
    if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getVideoTracks().forEach(track => track.enabled = newCameraState);
    } else if (newCameraState && hasCameraPermission === null) {
        // If camera was never initialized (e.g. permission denied then granted via settings), re-request
        const getCameraPermission = async () => {
          try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: true });
            setHasCameraPermission(true);
            if (videoRef.current) {
              videoRef.current.srcObject = stream;
            }
          } catch (error) {
            console.error('Error accessing camera:', error);
            setHasCameraPermission(false);
            toast({
              variant: 'destructive',
              title: 'Camera Access Denied',
              description: 'Please enable camera permissions in your browser settings.',
            });
          }
        };
        getCameraPermission();
    }
  };

  const handleToggleScreenShare = () => {
    const newScreenShareState = !isScreenSharing;
    setIsScreenSharing(newScreenShareState);
    toast({ title: `Screen sharing ${newScreenShareState ? 'started' : 'stopped'}` });
    console.log(`Screen sharing toggled ${newScreenShareState ? 'ON' : 'OFF'}`);
    // Add actual screen sharing logic here
  };

  const handleToggleRecording = () => {
    const newRecordingState = !isRecording;
    setIsRecording(newRecordingState);
    toast({ title: `Recording ${newRecordingState ? 'started' : 'stopped'}` });
    console.log(`Recording toggled ${newRecordingState ? 'ON' : 'OFF'}`);
    // Add actual recording logic here
  };

  const handleLeaveRoom = () => {
    toast({
      title: "Left Room",
      description: `You have left room: ${roomId}. Redirecting to dashboard...`,
      variant: "default",
    });
    console.log("Left room:", roomId);
    router.push('/');
  };


  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (chatInput.trim()) {
      setChatMessages(prev => [...prev, { user: 'You', message: chatInput, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
      setChatInput('');
      console.log("Chat message sent:", chatInput);
    }
  };

  if (!isClient && hasCameraPermission === null) { // Show loading skeleton only if client check & permission check haven't run
    return (
      <div className="flex flex-col lg:flex-row gap-4 h-[calc(100vh-200px)] animate-pulse">
        <div className="flex-grow bg-muted rounded-lg p-4 flex items-center justify-center">
          <div className="w-full h-full bg-muted-foreground/10 rounded"></div>
        </div>
        <div className="lg:w-80 xl:w-96 space-y-4">
          <div className="bg-muted rounded-lg p-4 h-1/2"></div>
          <div className="bg-muted rounded-lg p-4 h-1/2"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row gap-4 h-full max-h-[calc(100vh-220px)]"> {/* Adjusted max height */}
      {/* Main Content Area (Video Feeds / Screen Share) */}
      <div className="flex-grow bg-card rounded-lg shadow-md p-4 flex flex-col items-center justify-center relative overflow-hidden">
        <div className="absolute top-2 left-2 bg-primary/80 text-primary-foreground px-2 py-1 rounded-full text-xs shadow">
          Room: {roomId}
        </div>
        {isScreenSharing ? (
          <div className="w-full h-full flex flex-col items-center justify-center bg-foreground text-background">
            <ScreenShareIcon className="w-16 h-16 mb-4" />
            <p className="text-xl font-semibold">You are sharing your screen</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 w-full h-full place-items-center">
            {/* Main Speaker / Own Video */}
            <div className="w-full h-full bg-muted rounded-md flex items-center justify-center relative aspect-video max-w-full max-h-full">
              <video ref={videoRef} className="w-full h-full object-cover rounded-md" autoPlay muted playsInline />
              <span className="absolute bottom-2 left-2 bg-black/50 text-white px-2 py-1 text-xs rounded">You</span>
              {(!isCameraOn || hasCameraPermission === false) && (
                <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center text-white">
                  <VideoOffIcon className="w-12 h-12" />
                  {hasCameraPermission === false && <p className="mt-2 text-sm">Camera access denied.</p>}
                  {!isCameraOn && hasCameraPermission !== false && <p className="mt-2 text-sm">Camera is off.</p>}
                </div>
              )}
               {hasCameraPermission === null && ( // Still checking
                 <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center text-white">
                    <p>Requesting camera access...</p>
                 </div>
               )}
            </div>
             {/* Other participant placeholder */}
            <div className="w-full h-full bg-muted rounded-md flex items-center justify-center relative aspect-video max-w-full max-h-full">
               <Image src="https://placehold.co/600x400.png" alt="Participant video feed" layout="fill" objectFit="cover" className="rounded-md" data-ai-hint="person studying" />
              <span className="absolute bottom-2 left-2 bg-black/50 text-white px-2 py-1 text-xs rounded">Alice</span>
            </div>
          </div>
        )}
         {hasCameraPermission === false && !isScreenSharing && (
            <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 p-4">
                <Alert variant="destructive" className="max-w-md mx-auto">
                    <AlertTitle>Camera Access Required</AlertTitle>
                    <AlertDescription>
                        StudySphere needs access to your camera to display your video. 
                        Please enable camera permissions in your browser settings and refresh the page.
                    </AlertDescription>
                </Alert>
            </div>
        )}
        {/* Controls Bar */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-card/90 p-3 rounded-xl shadow-xl flex gap-3 border">
          <Button variant={isMicOn ? "outline" : "destructive"} size="icon" onClick={handleToggleMic} aria-label={isMicOn ? "Mute microphone" : "Unmute microphone"}>
            {isMicOn ? <MicIcon /> : <MicOffIcon />}
          </Button>
          <Button variant={isCameraOn && hasCameraPermission ? "outline" : "destructive"} size="icon" onClick={handleToggleCamera} aria-label={isCameraOn ? "Turn off camera" : "Turn on camera"} disabled={hasCameraPermission === false}>
            {isCameraOn && hasCameraPermission ? <VideoIcon /> : <VideoOffIcon />}
          </Button>
          <Button variant={isScreenSharing ? "secondary" : "outline"} size="icon" onClick={handleToggleScreenShare} aria-label={isScreenSharing ? "Stop screen sharing" : "Start screen sharing"}>
            {isScreenSharing ? <ScreenShareOffIcon className="text-primary"/> : <ScreenShareIcon />}
          </Button>
          <Button variant={isRecording ? "destructive" : "outline"} size="icon" onClick={handleToggleRecording} aria-label={isRecording ? "Stop recording" : "Start recording"}>
            <RadioIcon className={isRecording ? "animate-pulse text-red-500" : ""} />
          </Button>
           <Button variant="outline" size="icon" onClick={() => setShowNotes(s => !s)} aria-label="Toggle Notes Panel">
            <Edit3Icon />
          </Button>
          <Button variant="outline" size="icon" onClick={() => setShowPomodoro(s => !s)} aria-label="Toggle Pomodoro Timer">
            <ClockIcon />
          </Button>
          <Button variant="destructive" size="icon" onClick={handleLeaveRoom} aria-label="Leave room">
            <LogOutIcon />
          </Button>
        </div>
      </div>

      {/* Side Panel (Chat / Participants / Tools) */}
      <Card className="lg:w-80 xl:w-96 shadow-md flex flex-col max-h-full">
        <CardHeader className="pb-2">
          <div className="flex border-b">
            <Button variant={activeTab === 'chat' ? 'ghost' : 'ghost'} onClick={() => setActiveTab('chat')} className={`flex-1 rounded-none ${activeTab === 'chat' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}>
              <MessageSquareIcon className="mr-2 h-4 w-4" /> Chat
            </Button>
            <Button variant={activeTab === 'participants' ? 'ghost' : 'ghost'} onClick={() => setActiveTab('participants')} className={`flex-1 rounded-none ${activeTab === 'participants' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}>
              <UsersIcon className="mr-2 h-4 w-4" /> Participants ({mockParticipants.length})
            </Button>
          </div>
        </CardHeader>
        <CardContent className="flex-grow overflow-hidden flex flex-col min-h-0">
          {activeTab === 'chat' && (
            <>
              <ScrollArea className="flex-grow pr-2 mb-2 min-h-[100px]"> {/* min-h to ensure it's visible */}
                <div className="space-y-3">
                  {chatMessages.map((msg, i) => (
                    <div key={i} className={`flex ${msg.user === 'You' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`p-2 rounded-lg max-w-[80%] text-sm ${msg.user === 'You' ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                        <p className="font-semibold text-xs mb-0.5">{msg.user} <span className="text-xs font-normal opacity-70 ml-1">{msg.time}</span></p>
                        <p>{msg.message}</p>
                      </div>
                    </div>
                  ))}
                   {chatMessages.length === 0 && <p className="text-xs text-center text-muted-foreground py-4">No messages yet. Start the conversation!</p>}
                </div>
              </ScrollArea>
              <form onSubmit={handleSendMessage} className="flex gap-2 items-center pt-2 border-t">
                <Input value={chatInput} onChange={(e) => setChatInput(e.target.value)} placeholder="Type a message..." className="flex-grow" aria-label="Chat message input"/>
                <Button type="submit" size="icon" className="bg-primary hover:bg-primary/90" aria-label="Send message"><SendIcon /></Button>
              </form>
            </>
          )}
          {activeTab === 'participants' && (
            <ScrollArea className="flex-grow pr-2 min-h-[100px]">
              <ul className="space-y-2">
                {mockParticipants.map(p => (
                  <li key={p.id} className="flex items-center justify-between p-2 rounded-md hover:bg-muted/50">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={p.avatar} alt={p.name} data-ai-hint="profile avatar" />
                        <AvatarFallback>{p.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span className="text-sm">{p.name}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                        {p.micOn ? <MicIcon className="h-3.5 w-3.5 text-green-500" /> : <MicOffIcon className="h-3.5 w-3.5 text-destructive" />}
                        {p.videoOn ? <VideoIcon className="h-3.5 w-3.5 text-green-500" /> : <VideoOffIcon className="h-3.5 w-3.5 text-destructive" />}
                    </div>
                  </li>
                ))}
              </ul>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
      
      {/* Floating Notes Panel */}
       {showNotes && (
        <Card className="absolute bottom-20 right-4 lg:right-auto lg:left-[calc(50%-12rem)] w-80 h-96 shadow-xl z-20 flex flex-col border border-primary">
          <CardHeader className="py-2 px-3 bg-primary text-primary-foreground rounded-t-lg">
            <CardTitle className="text-base font-headline flex justify-between items-center">
              Notes
              <Button variant="ghost" size="sm" onClick={() => setShowNotes(false)} className="text-primary-foreground hover:bg-primary/80 p-1 h-auto">X</Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-3 flex-grow overflow-auto">
            <NotesPanel />
          </CardContent>
        </Card>
      )}

      {/* Floating Pomodoro Timer */}
      {showPomodoro && (
         <Card className="absolute top-20 right-4 lg:right-auto lg:left-[calc(50%-12rem)] w-80 shadow-xl z-20 flex flex-col border border-accent">
           <CardHeader className="py-2 px-3 bg-accent text-accent-foreground rounded-t-lg">
            <CardTitle className="text-base font-headline flex justify-between items-center">
              Pomodoro
              <Button variant="ghost" size="sm" onClick={() => setShowPomodoro(false)} className="text-accent-foreground hover:bg-accent/80 p-1 h-auto">X</Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0"> {/* PomodoroTimer has its own padding */}
            <PomodoroTimer />
          </CardContent>
        </Card>
      )}

    </div>
  );
}

