"use client";

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { BotIcon, SparklesIcon, AlertTriangleIcon, Loader2 } from 'lucide-react';
import { getPracticeQuestionsAction } from '@/app/_actions/aiActions';
import { useToast } from "@/hooks/use-toast";
import { ScrollArea } from '@/components/ui/scroll-area';

export default function AiPracticeGenerator() {
  const [studyMaterialUrl, setStudyMaterialUrl] = useState('');
  const [questions, setQuestions] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!studyMaterialUrl.trim()) {
      setError("Please enter a valid URL.");
      toast({
        title: "Input Error",
        description: "Please provide a URL for your study material.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    setError(null);
    setQuestions([]);

    const result = await getPracticeQuestionsAction({ studyMaterialUrl });

    setIsLoading(false);

    if ('error' in result) {
      setError(result.error);
      setQuestions([]);
      toast({
        title: "AI Error",
        description: result.error,
        variant: "destructive",
      });
    } else {
      setQuestions(result.questions);
      if (result.questions.length === 0) {
        toast({
          title: "No Questions Generated",
          description: "The AI couldn't generate questions from the provided material, or the material was empty.",
        });
      } else {
        toast({
          title: "Success!",
          description: `${result.questions.length} practice questions generated.`,
        });
      }
    }
  };

  return (
    <div className="space-y-4 h-full flex flex-col">
      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="flex items-center space-x-2">
          <BotIcon className="h-6 w-6 text-primary" />
          <p className="text-sm text-muted-foreground">
            Enter the URL of your study material to generate practice questions.
          </p>
        </div>
        <div className="flex space-x-2">
          <Input
            type="url"
            value={studyMaterialUrl}
            onChange={(e) => setStudyMaterialUrl(e.target.value)}
            placeholder="https://example.com/study-notes"
            className="flex-grow"
            aria-label="Study material URL"
            disabled={isLoading}
          />
          <Button type="submit" disabled={isLoading} className="bg-accent hover:bg-accent/90 text-accent-foreground">
            {isLoading ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <SparklesIcon className="mr-2 h-4 w-4" />
            )}
            Generate
          </Button>
        </div>
      </form>

      {error && (
        <div className="p-3 rounded-md bg-destructive/10 text-destructive flex items-center space-x-2 text-sm">
          <AlertTriangleIcon className="h-5 w-5" />
          <p>{error}</p>
        </div>
      )}

      {questions.length > 0 && (
        <div className="flex-grow flex flex-col min-h-0">
          <h3 className="font-headline text-lg mb-2 text-foreground">Generated Questions:</h3>
          <ScrollArea className="flex-grow border rounded-md p-3 bg-muted/30 max-h-[200px]"> {/* Adjusted max-h */}
            <ul className="space-y-2 text-sm">
              {questions.map((q, index) => (
                <li key={index} className="p-2 bg-background rounded shadow-sm">{q}</li>
              ))}
            </ul>
          </ScrollArea>
        </div>
      )}
    </div>
  );
}
