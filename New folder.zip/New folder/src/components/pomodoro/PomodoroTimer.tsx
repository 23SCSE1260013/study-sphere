"use client";

import { TimerIcon, SettingsIcon, PlayIcon, PauseIcon, RefreshCwIcon, SkipForwardIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePomodoro, PomodoroSessionType } from '@/hooks/usePomodoro';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import type { PomodoroSettings } from '@/lib/types';
import { useState, useEffect } from 'react';

const formatTime = (seconds: number) => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

export default function PomodoroTimer() {
  const { timeLeft, isRunning, currentSessionType, startPause, reset, settings, updateSettings, skipSession } = usePomodoro();
  const [localSettings, setLocalSettings] = useState<PomodoroSettings>(settings);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);
  
  useEffect(() => {
    setLocalSettings(settings);
  }, [settings]);

  const handleSettingsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setLocalSettings(prev => ({ ...prev, [name]: parseInt(value) || 0 }));
  };

  const saveSettings = () => {
    updateSettings(localSettings);
  };

  const totalDuration = currentSessionType === PomodoroSessionType.Work ? settings.workDuration * 60 : settings.breakDuration * 60;
  const progressPercentage = totalDuration > 0 ? ((totalDuration - timeLeft) / totalDuration) * 100 : 0;
  
  if (!isClient) {
    return (
      <div className="flex flex-col items-center space-y-4 p-4 rounded-lg bg-card-foreground/5">
        <div className="text-5xl font-mono font-bold text-primary">--:--</div>
        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
           <div className="h-full bg-primary transition-all duration-500" style={{ width: `0%` }}></div>
        </div>
        <div className="text-sm font-medium text-muted-foreground">Loading Timer...</div>
        <div className="flex space-x-2">
          <Button variant="outline" size="icon" disabled><PlayIcon /></Button>
          <Button variant="outline" size="icon" disabled><RefreshCwIcon /></Button>
          <Button variant="outline" size="icon" disabled><SkipForwardIcon /></Button>
          <Button variant="ghost" size="icon" disabled><SettingsIcon /></Button>
        </div>
      </div>
    );
  }


  return (
    <div className="flex flex-col items-center space-y-4 p-4 rounded-lg bg-card-foreground/5">
      <div className={`text-5xl font-mono font-bold ${currentSessionType === PomodoroSessionType.Work ? 'text-primary' : 'text-accent'}`}>
        {formatTime(timeLeft)}
      </div>
       <Progress value={progressPercentage} aria-label={`Time progress: ${Math.round(progressPercentage)}%`} className="w-full h-2 [&>div]:bg-primary" />
      <div className="text-sm font-medium text-muted-foreground">
        Current: {currentSessionType}
      </div>
      <div className="flex space-x-2">
        <Button variant="outline" onClick={startPause} aria-label={isRunning ? "Pause timer" : "Start timer"}>
          {isRunning ? <PauseIcon className="h-5 w-5" /> : <PlayIcon className="h-5 w-5" />}
          <span className="ml-2">{isRunning ? 'Pause' : 'Start'}</span>
        </Button>
        <Button variant="outline" onClick={reset} aria-label="Reset timer">
          <RefreshCwIcon className="h-5 w-5" />
           <span className="ml-2">Reset</span>
        </Button>
        <Button variant="outline" onClick={skipSession} aria-label="Skip to next session">
          <SkipForwardIcon className="h-5 w-5" />
          <span className="ml-2">Skip</span>
        </Button>
        <Dialog>
          <DialogTrigger asChild>
            <Button variant="ghost" size="icon" aria-label="Open pomodoro settings"><SettingsIcon /></Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle className="font-headline">Pomodoro Settings</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="workDuration" className="text-right">Work (min)</Label>
                <Input id="workDuration" name="workDuration" type="number" value={localSettings.workDuration} onChange={handleSettingsChange} className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="breakDuration" className="text-right">Break (min)</Label>
                <Input id="breakDuration" name="breakDuration" type="number" value={localSettings.breakDuration} onChange={handleSettingsChange} className="col-span-3" />
              </div>
            </div>
            <DialogFooter>
              <DialogClose asChild>
                <Button type="button" variant="secondary">Cancel</Button>
              </DialogClose>
              <DialogClose asChild>
                <Button type="submit" onClick={saveSettings} className="bg-primary hover:bg-primary/90">Save changes</Button>
              </DialogClose>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
