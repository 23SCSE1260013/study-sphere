
import Link from 'next/link';
import Image from 'next/image'; // Changed from CastleIcon
import UserNav from './UserNav'; // Import UserNav

export default function Header() {
  return (
    <header className="py-3 px-4 md:px-6 border-b bg-background/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
      <div className="container mx-auto flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <Image src="/logo.svg" alt="StudySphere Logo" width={32} height={32} className="text-primary transition-transform group-hover:scale-110" data-ai-hint="logo brain"/>
          <h1 className="text-2xl font-headline font-bold text-foreground transition-colors group-hover:text-primary/90">StudySphere</h1>
        </Link>
        
        {/* Navigation Links - Can be adjusted or moved into UserNav if it becomes complex */}
        {/* For now, core navigation like "Live Streams" can be part of UserNav or here if always visible */}
        {/* <nav className="hidden md:flex items-center gap-4 lg:gap-6">
          <Link href="/live" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
            Live Streams
          </Link>
        </nav> */}

        <UserNav />
      </div>
    </header>
  );
}
