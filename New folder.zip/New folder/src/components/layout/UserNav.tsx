
"use client";

import Link from 'next/link';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { signOutAction } from '@/app/_actions/authActions';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LogInIcon, LogOutIcon, UserCircle, UserPlusIcon, LayoutDashboardIcon, RadioIcon, ClapperboardIcon } from 'lucide-react'; // Added RadioIcon, ClapperboardIcon
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function UserNav() {
  const { currentUser, userProfile, loading } = useAuth();
  const { toast } = useToast();
  const router = useRouter();

  const handleSignOut = async () => {
    const result = await signOutAction();
    if (result.success) {
      toast({ title: "Signed Out", description: "You have been successfully signed out." });
      router.push('/login');
      router.refresh(); 
    } else {
      toast({ title: "Sign Out Failed", description: result.error || "Could not sign out.", variant: "destructive" });
    }
  };
  
  const getInitials = (name?: string | null, email?: string | null) => {
    if (name) return name.split(' ').map(n => n[0]).join('').toUpperCase();
    if (email) return email.charAt(0).toUpperCase();
    return 'U';
  };


  if (loading) {
    return <div className="h-9 w-28 rounded-md bg-muted animate-pulse flex items-center gap-2">
      <div className="h-6 w-16 bg-muted-foreground/20 rounded"></div>
      <div className="h-6 w-10 bg-muted-foreground/20 rounded"></div>
    </div>;
  }

  if (currentUser && userProfile) {
    return (
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/live">
            <ClapperboardIcon className="mr-2 h-4 w-4" />
            Live Streams
          </Link>
        </Button>
        <Button variant="default" size="sm" asChild className="bg-accent hover:bg-accent/90 text-accent-foreground">
          <Link href="/broadcast">
            <RadioIcon className="mr-2 h-4 w-4" />
            Go Live
          </Link>
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-9 w-9 rounded-full">
              <Avatar className="h-9 w-9">
                <AvatarImage src={userProfile.photoURL || `https://placehold.co/40x40.png?text=${getInitials(userProfile.displayName, userProfile.email)}`} alt={userProfile.displayName || "User"} data-ai-hint="profile avatar"/>
                <AvatarFallback>{getInitials(userProfile.displayName, userProfile.email)}</AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56" align="end" forceMount>
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col space-y-1">
                <p className="text-sm font-medium leading-none">{userProfile.displayName || "User"}</p>
                <p className="text-xs leading-none text-muted-foreground">
                  {userProfile.email}
                </p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link href="/" className="cursor-pointer">
                <LayoutDashboardIcon className="mr-2 h-4 w-4" />
                <span>Dashboard</span>
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href="/profile" className="cursor-pointer">
                <UserCircle className="mr-2 h-4 w-4" />
                <span>Profile</span>
              </Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleSignOut} className="cursor-pointer text-destructive focus:text-destructive focus:bg-destructive/10">
              <LogOutIcon className="mr-2 h-4 w-4" />
              <span>Log out</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
       <Button variant="ghost" size="sm" asChild>
          <Link href="/live">
            <ClapperboardIcon className="mr-2 h-4 w-4" />
            Live Streams
          </Link>
        </Button>
      <Button variant="outline" asChild>
        <Link href="/login">
          <LogInIcon className="mr-2 h-4 w-4" /> Login
        </Link>
      </Button>
      <Button asChild className="bg-primary hover:bg-primary/90">
        <Link href="/signup">
          <UserPlusIcon className="mr-2 h-4 w-4" /> Sign Up
        </Link>
      </Button>
    </div>
  );
}
