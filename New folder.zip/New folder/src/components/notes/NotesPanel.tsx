"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { SaveIcon, EraserIcon } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

export default function NotesPanel() {
  const [noteContent, setNoteContent] = useState('');
  const [isClient, setIsClient] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    setIsClient(true);
    const savedNote = localStorage.getItem('studySphereNote');
    if (savedNote) {
      setNoteContent(savedNote);
    }
  }, []);

  const handleSaveNote = () => {
    if(!isClient) return;
    localStorage.setItem('studySphereNote', noteContent);
    toast({
      title: "Note Saved",
      description: "Your note has been saved locally.",
    });
  };

  const handleClearNote = () => {
    setNoteContent('');
    if(isClient) {
      localStorage.removeItem('studySphereNote');
    }
    toast({
      title: "Note Cleared",
      description: "Your note has been cleared.",
      variant: "default", 
    });
  };

  if (!isClient) {
    return (
      <div className="space-y-3">
        <div className="h-40 bg-muted rounded-md animate-pulse"></div>
        <div className="flex space-x-2">
          <div className="h-10 w-24 bg-muted rounded-md animate-pulse"></div>
          <div className="h-10 w-24 bg-muted rounded-md animate-pulse"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3 h-full flex flex-col">
      <Textarea
        value={noteContent}
        onChange={(e) => setNoteContent(e.target.value)}
        placeholder="Start typing your notes here..."
        className="flex-grow min-h-[150px] resize-none text-sm"
        aria-label="Note taking area"
      />
      <div className="flex space-x-2">
        <Button onClick={handleSaveNote} className="bg-primary hover:bg-primary/90">
          <SaveIcon className="mr-2 h-4 w-4" /> Save Note
        </Button>
        <Button variant="outline" onClick={handleClearNote}>
          <EraserIcon className="mr-2 h-4 w-4" /> Clear Note
        </Button>
      </div>
    </div>
  );
}
