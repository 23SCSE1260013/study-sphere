(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__2b38bddc._.css",
  "static/chunks/d9ef2_@firebase_auth_dist_esm2017_fab980f7._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_c2fcaa2e.js",
  "static/chunks/node_modules_@firebase_storage_dist_index_esm2017_b3a08d2a.js",
  "static/chunks/node_modules_0fce3c60._.js",
  "static/chunks/src_203f5e0b._.js"
],
    source: "dynamic"
});
