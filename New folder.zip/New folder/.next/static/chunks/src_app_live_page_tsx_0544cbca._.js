(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_2f618241._.js",
  "static/chunks/node_modules_4749c153._.js"
],
    source: "dynamic"
});
